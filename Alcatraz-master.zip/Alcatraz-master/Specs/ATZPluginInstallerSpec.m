//
//  ATZPluginInstallerTests.m
//  Alcatraz
//
//  Created by Marin Usalj on 11/23/13.
//  Copyright (c) 2013 supermar.in. All rights reserved.
//

//#import <Kiwi/Kiwi.h>
//#import "ATZPluginInstaller.h"
//
//SPEC_BEGIN(PluginInstaller)
//
//describe(@"Installer", ^{
//   
////    let(installer, ^{ return [ATZPluginInstaller new]; });
//    
////    it(@"reports install progress", ^{
////
////    });
//    
//});
//
//SPEC_END
