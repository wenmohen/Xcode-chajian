//
//  ATZAppDelegate.m
//  TestProject
//
//  Created by Marin Usalj on 3/2/14.
//  Copyright (c) 2014 Marin Usalj. All rights reserved.
//

#import "ATZAppDelegate.h"

@implementation ATZAppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
}

@end
