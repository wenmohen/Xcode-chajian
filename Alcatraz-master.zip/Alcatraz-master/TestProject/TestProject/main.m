//
//  main.m
//  TestProject
//
//  Created by Marin Usalj on 3/2/14.
//  Copyright (c) 2014 Marin Usalj. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
