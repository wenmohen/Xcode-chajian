# 0.6.0
- add App Iconset generation

# 0.5.0
- Fix #21
- init set version number to `0.5.0`