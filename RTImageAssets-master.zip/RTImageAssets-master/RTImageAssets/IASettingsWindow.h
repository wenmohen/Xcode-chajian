//
//  IASettingsWindow.h
//  RTImageAssets
//
//  Created by ricky on 14-12-10.
//  Copyright (c) 2014年 rickytan. All rights reserved.
//

#import <Cocoa/Cocoa.h>

extern NSString *IASettingsGenerateNonRetinaKey;
extern NSString *IASettingsUpscaleKey;
extern NSString *IASettingsDownscaleKey;
extern NSString *IASettingsRename;

@interface IASettingsWindow : NSWindowController

@end
